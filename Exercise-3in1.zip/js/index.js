function FunOne() {
    return React.createElement(
        "div",
        { className: "Sample" },
        React.createElement(
            "h2",
            null,
            "Exercise-1"
        ),
        React.createElement(
            "p",
            null,
            "Come to Learn"
        )
    );
}
ReactDOM.render(React.createElement(FunOne, null), document.querySelector("#Exercise1"));

function FunTwo(props) {
    return React.createElement(
        "div",
        { className: "Sample" },
        React.createElement(
            "h2",
            null,
            props.h2
        ),
        React.createElement(
            "p",
            null,
            props.p2
        )
    );
}

ReactDOM.render(React.createElement(FunTwo, { h2: "Exercise-2", p2: "Come to Learn" }), document.querySelector("#Exercise2"));

function FunThree(props) {
    return React.createElement(
        "div",
        { className: "Sample" },
        React.createElement(
            "h2",
            null,
            props.h3
        ),
        React.createElement(
            "p",
            null,
            props.p3
        )
    );
}
var a = React.createElement(
    "div",
    null,
    React.createElement(FunThree, { h3: "Exercise-3", p3: "Come to Learn" })
);
ReactDOM.render(a, document.querySelector("#Exercise3"));